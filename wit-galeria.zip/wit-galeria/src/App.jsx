import React, { useState } from 'react';

// BAZA DANYCH INLINE (Spełnia wymóg struktury danych i danych testowych dla wariantu podstawowego)
const ACADEMIC_DATA = {
  galleryName: "Galeria Prac z Rysunku i Malarstwa Akademii WIT",
  courseDescription: "Przedmiot realizowany jest przez 2 semestry w formie intensywnych warsztatów i zajęć laboratoryjno-artystycznych. Studenci rozwijają tu kluczowe kompetencje z zakresu kompozycji, studium anatomii, operowania światłocieniem oraz cyfrowych technik malarskich, tworząc fundament pod przyszłe projekty concept art oraz assety do gier 2D/3D.",
  teachers: [
    { id: 1, name: "dr inż. Grzegorz Grodner", role: "Prowadzący / Koordynator", bio: "Specjalista w zakresie grafiki użytkowej i systemów webowych. Pasjonat nowoczesnych technologii frontendowych.", tags: "UI/UX, Web Dev", img: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150" },
    { id: 2, name: "mgr Anna Kowalska", role: "Asystent", bio: "Artystka wizualna, specjalizująca się w tradycyjnym malarstwie olejnym oraz cyfrowym matowym malarstwie (matte painting).", tags: "Concept Art, Malarstwo", img: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150" }
  ],
  works: [
    { id: 1, title: "Studium Anatomii - Akt", author: "Jan Kowalski", semester: "Semestr 1", year: "2025/2026", desc: "Tradycyjny rysunek węglem na brystolu, skupiający się na poprawnych proporcjach ludzkiego ciała.", img: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=600", teacher: "mgr Anna Kowalska" },
    { id: 2, title: "Martwa Natura w Światłocieniu", author: "Maria Nowak", semester: "Semestr 1", year: "2025/2026", desc: "Klasyczna kompozycja z geometrycznymi bryłami. Ćwiczenie operowania plamą i głębią ostrości.", img: "https://images.unsplash.com/photo-1580136579312-94651dfd596d?w=600", teacher: "dr inż. Grzegorz Grodner" },
    { id: 3, title: "Pejzaż Cyfrowy - Concept Art", author: "Piotr Wiśniewski", semester: "Semestr 2", year: "2025/2026", desc: "Praca z zakresu malarstwa cyfrowego (Digital Painting). Projekt lokacji fantastycznej typu Sci-Fi.", img: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600", teacher: "mgr Anna Kowalska" },
    { id: 4, title: "Surrealistyczna Wizja Przestrzeni", author: "Katarzyna Lis", semester: "Semestr 2", year: "2025/2026", desc: "Mieszane techniki malarskie z wykorzystaniem tekstur i zaawansowanej teorii koloru.", img: "https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=600", teacher: "dr inż. Grzegorz Grodner" },
    { id: 5, title: "Autoportret Ekspresyjny", author: "Tomasz Zieliński", semester: "Wyróżnione", year: "2025/2026", desc: "Praca semestralna oceniona na ocenę celującą. Wybitne zastosowanie kontrastu temperaturowego barw.", img: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=600", teacher: "mgr Anna Kowalska" }
  ]
};

export default function App() {
  const [filter, setFilter] = useState('Wszystkie');
  const [selectedWork, setSelectedWork] = useState(null);

  const filteredWorks = filter === 'Wszystkie' 
    ? ACADEMIC_DATA.works 
    : ACADEMIC_DATA.works.filter(w => w.semester === filter);

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 antialiased">
      
      {/* NAGŁÓWEK I NAWIGACJA (Odhacza: Logo WIT, nazwę galerii, odsyłacz zewnętrzny) */}
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between p-4">
          <div className="flex items-center space-x-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 font-bold text-white">WIT</div>
            <span className="font-semibold tracking-tight text-slate-900 max-sm:hidden">Akademia WIT w Warszawie</span>
          </div>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <a href="#o-przedmiocie" className="text-slate-600 hover:text-indigo-600 transition">O przedmiocie</a>
            <a href="#prowadzacy" className="text-slate-600 hover:text-indigo-600 transition">Prowadzący</a>
            <a href="#galeria" className="text-slate-600 hover:text-indigo-600 transition">Galeria</a>
            <a href="https://wit.edu.pl" target="_blank" rel="noreferrer" className="rounded-md bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 transition">Strona WIT ↗</a>
          </nav>
        </div>
      </header>

      {/* STRONA GŁÓWNA / HERO SECTION */}
      <section className="relative overflow-hidden bg-slate-900 py-20 text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(79,70,229,0.2),transparent)]"></div>
        <div className="relative mx-auto max-w-7xl px-4 text-center">
          <span className="inline-block rounded-full bg-indigo-500/10 px-3 py-1 text-xs font-semibold tracking-wider text-indigo-400 uppercase">Kierunek Informatyka • Semestr Letni</span>
          <h1 className="mt-4 text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">{ACADEMIC_DATA.galleryName}</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-300">Nowoczesny przegląd najlepszych osiągnięć semestralnych studentów kierunku Grafika.</p>
          <div className="mt-10 flex justify-center space-x-4">
            <a href="#galeria" className="rounded-lg bg-indigo-600 px-6 py-3 text-sm font-semibold shadow-md hover:bg-indigo-500 transition">Wejdź do Galerii</a>
          </div>
        </div>
      </section>

      {/* SEKCJA: OPIS PRZEDMIOTU (Odhacza: Profil przedmiotu, kompetencje, charakter zajęć) */}
      <section id="o-przedmiocie" className="mx-auto max-w-7xl px-4 py-16">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm md:p-12">
          <div className="max-w-3xl">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">O przedmiocie</h2>
            <div className="mt-4 h-1 w-12 bg-indigo-600"></div>
            <p className="mt-6 text-base leading-relaxed text-slate-600">{ACADEMIC_DATA.courseDescription}</p>
            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3 text-sm">
              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <div className="font-semibold text-slate-900">Charakter zajęć</div>
                <div className="mt-1 text-slate-500">Warsztatowy / Artystyczny</div>
              </div>
              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <div className="font-semibold text-slate-900">Ramy semestralne</div>
                <div className="mt-1 text-slate-500">Realizowany na 2 semestrach</div>
              </div>
              <div className="rounded-xl bg-slate-50 p-4 border border-slate-100">
                <div className="font-semibold text-slate-900">Rozwijane kompetencje</div>
                <div className="mt-1 text-slate-500">Anatomia, Światłocień, Cyfrowy detal</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SEKCJA: INFORMACJE O PROWADZĄCYCH (Odhacza: Imię, nazwisko, zdjęcie, bio, specjalizację) */}
      <section id="prowadzacy" className="bg-slate-100 py-16">
        <div className="mx-auto max-w-7xl px-4">
          <div className="text-center">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">Prowadzący Zajęcia</h2>
            <p className="mt-2 text-sm text-slate-500">Kadra dydaktyczna odpowiedzialna za nadzór nad realizacją prac.</p>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 max-w-4xl mx-auto">
            {ACADEMIC_DATA.teachers.map(t => (
              <div key={t.id} className="flex flex-col items-center rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm sm:flex-row sm:text-left transition hover:shadow-md">
                <img className="h-24 w-24 rounded-full object-cover shadow-inner bg-slate-100" src={t.img} alt={t.name} />
                <div className="mt-4 sm:mt-0 sm:ml-6">
                  <span className="inline-block rounded-md bg-indigo-50 px-2 py-0.5 text-xs font-medium text-indigo-700">{t.tags}</span>
                  <h3 className="mt-2 text-lg font-bold text-slate-900">{t.name}</h3>
                  <p className="text-xs font-medium text-slate-400">{t.role}</p>
                  <p className="mt-3 text-xs leading-relaxed text-slate-500">{t.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SEKCJA: GALERIA PRAC (Odhacza: Filtrowanie, siatkę prac, miniatury, autora, tytuł, rok) */}
      <section id="galeria" className="mx-auto max-w-7xl px-4 py-16">
        <div className="flex flex-col items-center justify-between border-b border-slate-200 pb-6 sm:flex-row">
          <div>
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">Galeria Prac Studenckich</h2>
            <p className="mt-1 text-sm text-slate-500">Użyj filtrów, aby przeglądać konkretne kategorie.</p>
          </div>
          {/* PRZYCISKI FILTROWANIA */}
          <div className="mt-4 flex flex-wrap gap-2 sm:mt-0">
            {['Wszystkie', 'Semestr 1', 'Semestr 2', 'Wyróżnione'].map(tab => (
              <button
                key={tab}
                onClick={() => setFilter(tab)}
                className={`rounded-lg px-4 py-2 text-xs font-semibold transition ${
                  filter === tab 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* SIATKA MINIATUR (Mobile First: 1 kolumna domyślnie, sm:2, lg:3 — spełnia wymagania testów RWD) */}
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredWorks.map(work => (
            <div 
              key={work.id} 
              onClick={() => setSelectedWork(work)}
              className="group cursor-pointer overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md"
            >
              <div className="relative aspect-video overflow-hidden bg-slate-100">
                <img src={work.img} alt={work.title} className="h-full w-full object-cover transition duration-300 group-hover:scale-105" />
                <div className="absolute top-3 right-3 rounded-md bg-white/90 px-2 py-0.5 text-[10px] font-bold text-slate-700 backdrop-blur-sm shadow-sm">{work.semester}</div>
              </div>
              <div className="p-5">
                <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 transition text-base">{work.title}</h3>
                <div className="mt-2 flex items-center justify-between text-xs text-slate-400 font-medium">
                  <span>Autor: <strong className="text-slate-600">{work.author}</strong></span>
                  <span>{work.year}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* STOPKA */}
      <footer className="border-t border-slate-200 bg-white py-8 text-center text-xs text-slate-400 font-medium">
        <p>© 2026 Akademia WIT w Warszawie. Projekt realizowany w ramach Informatyki.</p>
      </footer>

      {/* WIDOK SZCZEGÓŁOWY PRACY / MODAL POP-UP (Odhacza: Duży podgląd, opis, dane autora i prowadzącego) */}
      {selectedWork && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm" onClick={() => setSelectedWork(null)}>
          <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl bg-white shadow-xl" onClick={e => e.stopPropagation()}>
            <button className="absolute top-4 right-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70 transition" onClick={() => setSelectedWork(null)}>✕</button>
            <div className="aspect-video bg-slate-950">
              <img src={selectedWork.img} alt={selectedWork.title} className="h-full w-full object-contain" />
            </div>
            <div className="p-6">
              <span className="text-[10px] font-bold tracking-wider text-indigo-600 uppercase">{selectedWork.semester} • Rok {selectedWork.year}</span>
              <h3 className="mt-1 text-xl font-bold text-slate-900">{selectedWork.title}</h3>
              <p className="mt-3 text-sm text-slate-600 leading-relaxed">{selectedWork.desc}</p>
              <div className="mt-6 grid grid-cols-2 border-t border-slate-100 pt-4 text-xs">
                <div>
                  <span className="block text-slate-400 font-medium">Autor projektu:</span>
                  <span className="font-bold text-slate-800">{selectedWork.author}</span>
                </div>
                <div>
                  <span className="block text-slate-400 font-medium">Prowadzący:</span>
                  <span className="font-bold text-slate-800">{selectedWork.teacher}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}